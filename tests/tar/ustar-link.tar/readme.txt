Rescue cloud recovery corpus / 復元テスト / 0123456789
